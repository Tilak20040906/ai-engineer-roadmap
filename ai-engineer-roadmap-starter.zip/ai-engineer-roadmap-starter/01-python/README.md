# Python for AI

Use this folder for small exercises and notes you wrote yourself.

## Suggested exercises
- [ ] Functions and return values
- [ ] Lists, dictionaries, sets, and comprehensions
- [ ] Read and write CSV/JSON files
- [ ] Exception handling
- [ ] Classes and objects
- [ ] Virtual environments and pip
- [ ] NumPy arrays
- [ ] pandas DataFrames

For each exercise, include a short problem statement, your solution, and one paragraph explaining the approach.
