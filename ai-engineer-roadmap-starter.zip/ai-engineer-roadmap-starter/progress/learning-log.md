# Learning Log

Keep each entry brief and specific. Record what you actually did, not what you planned to do.

## Week 1 — Template
- Dates:
- Study time:
- Topics learned:
- Code/exercises completed:
- What I can now explain:
- Questions or mistakes:
- Next week's goal:
- Commit/PR links:

## Weekly entries
(Add a new section each week. Link to notebooks or project folders where useful.)
