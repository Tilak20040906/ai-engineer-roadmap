# Projects

Create a folder for each project. Each project should include:
- Problem statement and intended user
- Dataset source and license/usage notes
- Setup and run instructions
- Training/evaluation procedure
- Metrics and results (never invent results)
- Limitations and next steps
- Screenshots or demo link where useful

Do not commit secrets, private/company code, personal data, or datasets you are not permitted to redistribute.
